function [final_image] = filter_3D(dataparams,sum_fft,Nx,Ny,Nz,lambdaregul1,lambdaregul2,output,disp_flag)

%% Calculate the Frequency mask
Mask_final = ones(Nx,Ny,Nz);
Mask_final(sum_fft==0)=0;

%% Ccalucalte filter1
lambdaregul = lambdaregul1;
Filter1 = get_filter1(dataparams,lambdaregul).*Mask_final;
lambdaregul = lambdaregul2;
Filter2 = get_filter2(dataparams,lambdaregul).*Mask_final;

%% Do the filter
sum_fft1 = sum_fft.*Filter1.*Filter2;
final_image = fftshift(abs(ifftn(ifftshift(sum_fft1))));
fft_ = fftshift(fftn(final_image));
if disp_flag == 1
    figure(5);
    subplot(211);imshow(1+log(abs(fft_ (:,:,floor(Nz/2)+1))),[]);title('Final FFT in xoy plane')
    subplot(212);imshow(1+log(abs(squeeze(fft_ (:,floor(Nx/2)+1,:)))),[]);title('Final FFT in xoz plane')
end

%% Save the results
maxnum = max(max(max(final_image)));
final_image = final_image./maxnum;
stackfilename = [output ,'Open_3DSIM.tif'];
for k = 1:Nz
    imwrite(final_image(:,:,k), stackfilename, 'WriteMode','append') % д��stackͼ��
end

