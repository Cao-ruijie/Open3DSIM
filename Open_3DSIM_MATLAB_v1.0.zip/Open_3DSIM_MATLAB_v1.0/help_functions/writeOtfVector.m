function [ ret ] = writeOtfVector( vec,otf,band, kx, ky )
    ret=otfToVector(vec,otf,band,kx,ky,0,1);
end


